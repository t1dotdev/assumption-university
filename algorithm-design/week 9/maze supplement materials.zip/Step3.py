
class state:
    def __init__(self, row, column, step):
        self.r = row
        self.c = column
        self.step = step

        
